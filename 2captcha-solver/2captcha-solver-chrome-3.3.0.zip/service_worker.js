importScripts(
    '/common/config.js',
    '/common/api.js',
    '/background/background.js',
    '/content/captcha/normal/background.js'
);